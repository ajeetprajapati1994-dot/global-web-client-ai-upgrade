# Global Web Client AI — Free-first starter

Features:
- Responsive dashboard
- Basic URL-level website review and improvement checklist
- Lead pipeline stored in browser local storage
- Outreach, proposal and follow-up template generator
- CSV export
- Node.js built-in HTTP server; no npm dependencies

## Run locally
Requires Node.js 18+.
1. Extract ZIP.
2. Open a terminal in the extracted folder.
3. Run `npm start`.
4. Visit http://localhost:3000

## Deploy to Render
1. Push this project to a new GitHub repository.
2. Create a separate Render Web Service connected to that repository.
3. Runtime: Node.
4. Build command: leave blank.
5. Start command: `npm start`.
6. Deploy and test before making any production changes.

## Important
This is a starter/demo, not a fully autonomous AI or production SaaS. Copy generation is template-based and does not use an LLM API. Website review is a basic URL-level heuristic, not a crawl or measured PageSpeed report. Leads live in the browser and do not sync across users/devices. Subscription billing, authentication, Google Maps API and automatic outreach are not included. Do not scrape Google Maps or send unsolicited bulk messages.

Next: add PageSpeed Insights integration, Supabase authentication/database with row-level security, a vetted AI provider, payment checkout and verified webhooks. Never expose API secrets in frontend code.